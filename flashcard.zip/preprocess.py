import wikipedia

def get_intro(n):
    # return a list of strings, each string is a paragraph
    para = wikipedia.summary(n)
    para = para.split('\n')
    return para

def get_full(n):
    # return a dictionary, each key is the name of a part
    # each content of a key is a list of strings, each string is a paragraph
    sec = wikipedia.page(n).content
    sec = sec.split('\n')
    # remove empty strings
    while "" in sec:
        sec.remove("")
    # remove introduction and endings
    for i, part in enumerate(sec):
        if part[:2]=="==":
            sec = sec[i:]
            break
    for i, part in enumerate(sec):
        if part=="== See also ==":
            sec = sec[:i]
            break
    # store each section in a dictionary
    part_list=[]
    for i, part in enumerate(sec):
        if part[:3]=="== ":
            part_list.append(i)
    text={}
    if len(part_list)==1:
        text[sec[0]]=sec[1:]
    else:
        for i, index in enumerate(part_list):
            if i==0:
                text[sec[index]]=sec[1:part_list[i+1]]
                continue
            if i==len(part_list)-1:
                text[sec[index]]=sec[index+1:]
                continue
            else:
                text[sec[index]]=sec[index+1:part_list[i+1]]

    return text