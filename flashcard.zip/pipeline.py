# from wiki name to flashcards
from summarizer import Summarizer
from QG import QueGenerator
import wikipedia

if __name__=="__main__":
    print("Please ignore the following warnings.")
    # initiate summarizer
    bart = Summarizer()
    # initiate question generator
    qg = QueGenerator(model_dir="/Users/southdam/Desktop/Master-Project-Flashcard")
    # force the code to run repeatly to save the time from
    # loading models if users would like to generate flashcards multiple times
    while True: 
        while True:
            name = input("Please input a name of a wikipedia page (input break to terminate): ")
            if name=="break":
                break
            try:
                wikipedia.summary(name)
                break
            except:
                print("Your input name may refer to more than one page. (ambiguous)")
        if name=="break":
            break
        while True:
            level = input("Please input the level you want [intro/full]: ")
            if level == "intro":
                break
            elif level == "full":
                print("Sorry, full level is not supported yet.")
            else:
                print("Looks like you typed something wrong :)")
    
        print("Now we know your choice, young man, then you have to wait....")
        print("(The process may take a few minutes)")
        # generate summary
        if level == "intro":
            summary = bart.ForRough(name)
        elif level == "full":
            pass
        else:
            pass
        print("we are almost there")
        cards = qg.generate(summary)
        print("     ")
        print("     ")
        print(summary)
        print("     ")
        print("Questions for you: ")
        # output questions and answers which are good enough
        for card in cards:
            if card["isGood"]:
                print(card["question"])
        print("Hints: ")
        for card in cards:
            if card["isGood"]:
                print(card["answer"])