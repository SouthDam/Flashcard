from transformers import (
    BartTokenizer, 
    BartForConditionalGeneration, 
    BartConfig,
    AutoModelWithLMHead, 
    AutoTokenizer,
    AutoModelForSeq2SeqLM
)
from preprocess import get_intro
import torch

class Summarizer():
    def __init__(self):
        self.model = AutoModelForSeq2SeqLM.from_pretrained("facebook/bart-large-cnn")
        self.tokenizer = AutoTokenizer.from_pretrained("facebook/bart-large-cnn")
        
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.model = self.model.to(self.device)

    def ForRough(self, name):
        """
        The input should be the name of a wikipedia page
        The output is the summary of its introduction part
        """
        text = get_intro(name)
        # summary of paragraphs
        para_summary = self.summarize(text)
        para_summary = [para_summary]
        # final output summary
        summary = self.summarize(para_summary,stage=2)
        return summary

    def summarize(self, p, stage=1):
        """
        Input: a list of string, ideally list of paragraphs
        Output: string, combination of summaries of input strings
        """
        summary = str()
    
        for i in range(len(p)):
            if len(p[i])<50:
                continue
            if stage==1:
                ip = self.tokenizer.encode("summarize: "+p[i], return_tensors="pt", max_length=1024, truncation=True)
                op = self.model.generate(ip, max_length=250, length_penalty=2.0, num_beams=4, early_stopping=True)
            if stage==2:
                ip = self.tokenizer.encode("summarize: "+p[i], return_tensors="pt", max_length=1024, truncation=True)
                op = self.model.generate(ip, max_length=250, min_length=80, length_penalty=2.0, num_beams=4, early_stopping=True)
            op = self.tokenizer.decode(op[0],skip_special_tokens=True)
            if op[-1] != ".":
                op += "."
            summary += op
            summary += " "
        summary=summary[:-1]
        return summary